<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Você ganhar pequenos pedaços da moeda dogecoin, você poder colocar varias maquinas assim você aumentaram o quantidade de moedas. Não nós importamos quantas maquinas você usar, nós importamos com a quantidade de hash obtidos, antes de minerar verificar-se se o computador está superaquecendo, nós não responsabilizamos por danos as maquinas o usuário é responsável pelas suas ações tem que configurar corretamente a maquina e se está superaquecendo diminuir os núcleo e as potência para não ocasionar em problemas para a maquina." />
    <title>AutoFaucet - @yield('titulo')</title>
    @stack('estilosPage')
</head>
<body id="corpo">
    <div class="conteudo">
        @yield('conteiner')
        
        
</div>
<div id="dropDownSelect1"></div>
    @stack('scriptPage')
    
    <div class="py-3"><div class="container" style="margin-top: 10%;">
    <div class="row"></div>
    <div class="row">
      <div class="col-md-12 d-flex align-items-center justify-content-center my-3"> <a href="https://www.facebook.com/theslex26/"  target=”_blank”>
          <i class="d-block fa fa-facebook-official text-muted fa-lg mr-2"></i>
        </a> <a href="https://www.instagram.com/theslex6223/" target=”_blank”>
          <i class="d-block fa fa-instagram text-muted fa-lg mx-2"></i>
        </a>   <a href="https://twitter.com/The_Slex" target=”_blank”>
          <i class="d-block fa fa-twitter text-muted fa-lg ml-2"></i>
        </a> </div>
    </div>
    <div class="row">
      <div class="col-md-12 text-center">
        <p class="mb-0">©2019 Almerindo Junior by The Slex. Todos os direitos reservados </p>
      </div>
    </div></div>
  </div>
</body>
    
</html>