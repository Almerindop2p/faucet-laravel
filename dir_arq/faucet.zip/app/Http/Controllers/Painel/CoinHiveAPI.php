<?php

namespace App\Http\Controllers\Painel;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CoinHiveAPI extends Controller
{
    const API_URL = 'https://api.minero.cc/';
	private $secret = null;
	public function __construct($secret = "4bc6c7d7fd2dedd7926fbebee69ae0a7") {
		if (strlen($secret) !== 32) {
			throw new Exception('Mineiro - Invalid Secret');
		}
		$this->secret = $secret;
    }
    
    function get($path, $data = []) {
		$data['secret'] = $this->secret;
		$url = self::API_URL.$path.'?'.http_build_query($data);
		$response = file_get_contents($url);
		return json_decode($response);
	}
	
	function post($path, $data = []) {
		$data['secret'] = $this->secret;
		$context = stream_context_create([
			'http' => [
				'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
				'method'  => 'POST',
				'content' => http_build_query($data)
			]
		]);
		$url = SELF::API_URL.$path;
		$response = file_get_contents($url, false, $context);
		return json_decode($response);
    }
    

}
