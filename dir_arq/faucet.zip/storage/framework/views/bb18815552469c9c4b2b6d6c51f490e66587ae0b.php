<div id="modal-Reload" class="md_Reload-conteiner">
    <img src="./_css/_img/miner.gif" alt=""/>
</div><!-- fim load-->
</body>
</html>

<?php /**PATH C:\faucet\resources\views/Templade/fundo.blade.php ENDPATH**/ ?>